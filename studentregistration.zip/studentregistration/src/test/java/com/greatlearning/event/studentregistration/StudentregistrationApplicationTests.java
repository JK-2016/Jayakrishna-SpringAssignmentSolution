package com.greatlearning.event.studentregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentregistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
